import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:always/theme/customCheckBox.dart';
import '../../theme/glass_inline_dropdown.dart';
import '../../theme/glass.dart';

import 'add_photo.dart';
import 'photo_preview_screen.dart';
import 'case_summary_screen.dart';

class NewCaseScreen extends StatefulWidget {
  const NewCaseScreen({
    super.key,
    this.initialGender,
    this.initialAge,
    this.initialLocation,
    this.initialSymptoms,
  });

  final String? initialGender;
  final String? initialAge;
  final String? initialLocation;
  final List<String>? initialSymptoms;

  @override
  State<NewCaseScreen> createState() => _NewCaseScreenState();
}

class _NewCaseScreenState extends State<NewCaseScreen> {
  String? _selectedGender;
  String? _selectedAge;
  String? _selectedSpecificLocation;

  late final TextEditingController _hashController;

  final Map<String, bool> _symptoms = {
    'raised scar': false,
    'Red marks': false,
    'Sunbathe': false,
    'Fair skin': false,
    'The patient has a history of organ transplantation': false,
    'The patient has been exposed to arsenic': false,
    'The patient has photosensitivity': false,
    'The patient has a history of skin disease': false,
    'The patient has relatives who have had cancer.': false,
  };

  String _generateHashNo() {
    final now = DateTime.now();
    return '${now.day}${now.month.toString().padLeft(2, '0')}${now.year}01';
  }

  @override
  void initState() {
    super.initState();
    _selectedGender = widget.initialGender;
    _selectedAge = widget.initialAge;
    _selectedSpecificLocation = widget.initialLocation;
    _hashController = TextEditingController(text: _generateHashNo());

    if (widget.initialSymptoms != null) {
      for (final s in widget.initialSymptoms!) {
        if (_symptoms.containsKey(s)) {
          _symptoms[s] = true;
        }
      }
    }
  }

  @override
  void dispose() {
    _hashController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    // const primaryColor = Color(0xFF282828);

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: isDark
      ? const Color(0xFF0F0F0F)
      : const Color(0xFFFBFBFB),
      appBar: _buildAppBar(isDark),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 42),
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _sectionTitle('Visit Data', isDark),
              const SizedBox(height: 15),

              _buildGlassSection(
                isDark: isDark,
                child: Column(
                  children: [
                    _buildTextField(
                      label: 'Hash No.',
                      controller: _hashController,
                      isReadOnly: true,
                      isDark: isDark,
                    ),
                    const SizedBox(height: 16),

                    Row(
                      children: [
                        Expanded(
                          child: GlassInlineDropdown(
                            label: 'Gender',
                            hint: 'Select',
                            value: _selectedGender,
                            items: const ['M', 'W'],
                            isDark: isDark,
                            onChanged:
                                (v) => setState(() => _selectedGender = v),
                          ),
                        ),
                        const SizedBox(width: 20),
                        Expanded(
                          child: GlassInlineDropdown(
                            label: 'Age',
                            hint: 'Select',
                            value: _selectedAge,
                            items: List.generate(130, (i) => '${i + 1}'),
                            isDark: isDark,
                            onChanged: (v) => setState(() => _selectedAge = v),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 25),
              _sectionTitle('Symptoms', isDark),
              const SizedBox(height: 10),

              _buildGlassSection(
                isDark: isDark,
                padding: const EdgeInsets.all(12),
                child: _buildSymptomCheckboxes(isDark),
              ),

              const SizedBox(height: 25),
              _sectionTitle('Location', isDark),
              const SizedBox(height: 15),

              _buildGlassSection(
                isDark: isDark,
                child: Column(
                  children: [
                    GlassInlineDropdown(
                      label: 'Specific Location',
                      hint: 'Select Specific Location',
                      value: _selectedSpecificLocation,
                      items: const ['Face', 'Arm', 'Leg', 'Back'],
                      isDark: isDark,
                      onChanged:
                          (v) => setState(() => _selectedSpecificLocation = v),
                    ),
                    const SizedBox(height: 20),
                    _bodyMapPlaceholder(isDark),
                  ],
                ),
              ),

              const SizedBox(height: 30),
              _bottomButtons(isDark),
            ],
          ),
        ),
      ),
    );
  }


  PreferredSizeWidget _buildAppBar(bool isDark) {
  return PreferredSize(
    preferredSize: const Size.fromHeight(kToolbarHeight),
    child: Stack(
      children: [
        Container(
          height: kToolbarHeight,

          decoration: BoxDecoration(
            color: isDark
          ? Color(0xFF000000)
          :Color(0xFFFBFBFB),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(isDark ? 0.35 : 0.18),
                blurRadius: 24,
                offset: const Offset(0, 12),
              ),
            ],
          ),
        ),

        AppBar(
          title: Text(
            'New Case',
            style: GoogleFonts.inter(
              fontWeight: FontWeight.bold,
              fontSize: 20,
              color: isDark ? Colors.white : Colors.black,
            ),
          ),
          centerTitle: true,
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: BackButton(
            color: isDark ? Colors.white : Colors.black,
          ),
          flexibleSpace: ClipRRect(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
              child: Container(
                color: isDark
                    ? Colors.black.withOpacity(0.45)
                    : const Color(0xFFFBFBFB),
              ),
            ),
          ),
        ),
      ],
    ),
  );
}


  Widget _sectionTitle(String text, bool isDark) {
    return Text(
      text,
      style: GoogleFonts.inter(
        fontSize: 22,
        fontWeight: FontWeight.bold,
        color: isDark ? Colors.white : const Color(0xFF282828),
      ),
    );
  }

  Widget _buildGlassSection({
    required bool isDark,
    required Widget child,
    EdgeInsets padding = const EdgeInsets.all(20),
  }) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          padding: padding,
          decoration: glassBoxSection(isDark, radius: 16),
          child: child,
        ),
      ),
    );
  }

  Widget _buildTextField({
    required String label,
    required TextEditingController controller,
    bool isReadOnly = false,
    required bool isDark,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            color: isDark ? Colors.white70 : Colors.grey.shade700,
          ),
        ),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          readOnly: isReadOnly,
          decoration: InputDecoration(
            filled: true,
            fillColor:
                isDark ? Colors.white.withOpacity(0.08) : Colors.grey.shade100,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
          ),
        ),
      ],
    );
  }

  Widget _buildSymptomCheckboxes(bool isDark) {
    return Column(
      children:
          _symptoms.keys.map((key) {
            return customCheckboxRow(
              label: key,
              value: _symptoms[key]!,
              isDark: isDark,
              onChanged: (v) => setState(() => _symptoms[key] = v),
            );
          }).toList(),
    );
  }

  Widget _bodyMapPlaceholder(bool isDark) {
    return AspectRatio(
      aspectRatio: 1,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isDark ? Colors.white24 : Colors.grey.shade300,
          ),
        ),
        child: const Center(child: Text('[Body Map]')),
      ),
    );
  }

  Widget _bottomButtons(bool isDark) {
    return Row(
      children: [
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(25),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: OutlinedButton(
                onPressed: () => Navigator.pop(context),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  side: BorderSide(
                    color:
                        isDark
                            ? Colors.white.withOpacity(0.5)
                            : Colors.grey.shade400,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25),
                  ),
                  foregroundColor:
                      isDark ? Colors.white70 : Colors.grey.shade700,
                ),
                child: const Text(
                  'Cancel',
                  style: TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(25),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: ElevatedButton(
                onPressed: () => _showConfirmDialog(context),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  backgroundColor:
                      isDark ? Colors.white.withOpacity(0.9) : Colors.black,
                  foregroundColor: isDark ? Colors.black : Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25),
                  ),
                ),
                child: const Text(
                  'Finalize',
                  style: TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _showConfirmDialog(BuildContext context) {
  showDialog(
    context: context,
    barrierDismissible: false,

    barrierColor: const Color.fromARGB(255, 223, 223, 223).withOpacity(0.25),

    builder: (dialogContext) {
      final isDark =
          Theme.of(dialogContext).brightness == Brightness.dark;

      return Stack(
        children: [
          BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: 5, 
              sigmaY: 5,
            ),
            child: Container(
              color: Colors.transparent,
            ),
          ),

          Center(
            child: Dialog(
              backgroundColor: Colors.transparent,
              insetPadding: const EdgeInsets.symmetric(horizontal: 28),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: BackdropFilter(
                  filter: ImageFilter.blur(
                    sigmaX: 10,
                    sigmaY: 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.all(22),
                    decoration: BoxDecoration(
                      color: isDark
                          ? const Color(0xFF282828)
                          : Colors.white.withOpacity(0.92),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(
                            isDark ? 0.45 : 0.25,
                          ),
                          blurRadius: 30,
                          offset: const Offset(0, 15),
                        ),
                      ],
                    ),

                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.location_on_outlined,
                          size: 42,
                          color: isDark
                              ? const Color(0xFFFBFBFB)
                              : const Color(0xFF282828),
                        ),
                        const SizedBox(height: 14),

                        Text(
                          'Confirm this location?',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: isDark
                                ? Colors.white
                                : const Color(0xFF282828),
                          ),
                        ),

                        const SizedBox(height: 6),

                        Text(
                          'You are going to take photo of a lesion',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 14,
                            color: isDark
                                ? const Color(0xFFB8B8B8)
                                : const Color(0xFF6B6B6B),
                          ),
                        ),

                        const SizedBox(height: 24),

                        // ===============================
                        // 4️⃣ BUTTONS
                        // ===============================
                        Row(
                          children: [
                            // Cancel
                            Expanded(
                              child: ElevatedButton(
                                onPressed: () =>
                                    Navigator.of(dialogContext).pop(),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: isDark
                                      ? const Color(0xFF1F1F1F)
                                      : Colors.black,
                                  foregroundColor: Colors.white,
                                  elevation: 0,
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 12,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                                child: const Text(
                                  'Cancel',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ),

                            const SizedBox(width: 14),

                            // Confirm
                            Expanded(
                              child: ElevatedButton(
                                onPressed: () async {
                                  Navigator.of(dialogContext).pop();

                                  final List<String>? result =
    await showDialog<List<String>>(
  context: context,
  barrierDismissible: false,
    barrierColor: const Color.fromARGB(255, 223, 223, 223).withOpacity(0.25),


  builder: (_) {
    return Stack(
      children: [
        // 🔹 BLUR BACKGROUND
        BackdropFilter(
          filter: ImageFilter.blur(
            sigmaX: 5,
            sigmaY: 5,
          ),
          child: Container(
            color: Colors.transparent,
          ),
        ),

        // 🔹 ADD PHOTO DIALOG
        const Center(
          child: AddPhotoDialog(),
        ),
      ],
    );
  },
);


                                  if (result == null || result.isEmpty) return;
                                  if (!context.mounted) return;

                                  final caseId = _generateHashNo();

                                  final selectedSymptoms = _symptoms.entries
                                      .where((e) => e.value)
                                      .map((e) => e.key)
                                      .toList();

                                  final bool? shouldSave =
                                      await Navigator.of(context).push<bool>(
                                    MaterialPageRoute(
                                      builder: (_) => PhotoPreviewScreen(
                                        imagePath: result.first,
                                        imagePaths: result,
                                        caseId: caseId,
                                        isMultiImage: result.length > 1,
                                        imageCount: result.length,
                                      ),
                                    ),
                                  );

                                  if (shouldSave == true &&
                                      context.mounted) {
                                    await Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder: (_) => CaseSummaryScreen(
                                          caseId: caseId,
                                          gender: _selectedGender,
                                          age: _selectedAge,
                                          location:
                                              _selectedSpecificLocation,
                                          symptoms: selectedSymptoms,
                                          imagePaths: result,
                                          imagePath: result.first,
                                          isPrePrediction: true,
                                        ),
                                      ),
                                    );
                                  }
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor:
                                      const Color(0xFF007AFF),
                                  foregroundColor: Colors.white,
                                  elevation: 0,
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 12,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                                child: const Text(
                                  'Confirm',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      );
    },
  );
}

}
