# Alskin Backend Server Documentation


## 📖 Table of Contents
1. [System Overview](#-system-overview)
2. [Architecture & Data Flow](#-architecture--data-flow)
3. [Visual Workflows](#-visual-workflows)
4. [Project Structure Deep Dive](#-project-structure-deep-dive)
5. [Setup & Installation](#-setup--installation)
6. [API Reference](#-api-reference)
7. [Configuration](#-configuration)
8. [AI Model Details](#-ai-model-details)
9. [Troubleshooting](#-troubleshooting)

---

## 🔭 System Overview

The **Alskin Backend** is a high-performance REST API built with **FastAPI**. It serves as the bridge between the Flutter mobile app and the AI diagnosis model.

### Key Responsibilities
1.  **Sanity Checks:** Validates uploaded images for clarity (Blur Detection) before processing.
2.  **AI Inference:** Loads a PyTorch ResNet50 model to classify skin lesions.
3.  **Data Persistence:** Logs patient cases and saves images to the local file system.
4.  **API Services:** Provides endpoints for the mobile app to consume.

---

## 🏗 Architecture & Data Flow

The system follows a layered architecture pattern. The diagram below shows how data moves from the app to the server and back.

![Architecture Diagram](https://mermaid.ink/img/Z3JhcGggVEQKICAgIENsaWVudFvwn5OxIEZsdXR0ZXIgTW9iaWxlIEFwcF0KICAgIEFQSVvwn5qAIEZhc3RBUEkgU2VydmVyXQogICAgRW5naW5lW/Cfp6AgQUkgSW5mZXJlbmNlIEVuZ2luZV0KICAgIFN0b3JhZ2Vb8J+TgiBMb2NhbCBTdG9yYWdlXQoKICAgIENsaWVudCAtLSAiMS4gUE9TVCAvY2hlY2staW1hZ2UiIC0tPiBBUEkKICAgIEFQSSAtLSAiMi4gVmFsaWRhdGUgJiBQcmVwcm9jZXNzIiAtLT4gQVBJCiAgICBBUEkgLS0gIjMuIFJlcXVlc3QgUHJlZGljdGlvbiIgLS0+IEVuZ2luZQogICAgRW5naW5lIC0tICI0LiBSZXR1cm4gUHJvYmFiaWxpdGllcyIgLS0+IEFQSQogICAgQVBJIC0tICI1LiBTYXZlIEltYWdlICYgTWV0YWRhdGEiIC0tPiBTdG9yYWdlCiAgICBBUEkgLS0gIjYuIEpTT04gUmVzcG9uc2UgKERpYWdub3NpcykiIC0tPiBDbGllbnQ=)

### Technology Stack
-   **Framework:** FastAPI (Python) - *Fast, async, and auto-validating.*
-   **Computer Vision:** OpenCV (`cv2`) - *Used for blur detection.*
-   **AI/ML:** PyTorch (`torch`) - *Runs the ResNet50 model.*
-   **Validation:** Pydantic - *Ensures data integrity for requests/responses.*

---

## 📊 Visual Workflows

### 1. Image Check Workflow (`/check-image`)
This is the core loop where the Doctor/GP takes a photo, and the server processes it.

![Sequence Diagram](https://mermaid.ink/img/c2VxdWVuY2VEaWFncmFtCiAgICBwYXJ0aWNpcGFudCBBcHAgYXMgTW9iaWxlIEFwcAogICAgcGFydGljaXBhbnQgU2VydmVyIGFzIEZhc3RBUEkgU2VydmVyCiAgICBwYXJ0aWNpcGFudCBDViBhcyBPcGVuQ1YgKEJsdXIgQ2hlY2spCiAgICBwYXJ0aWNpcGFudCBBSSBhcyBQeVRvcmNoIE1vZGVsCiAgICBwYXJ0aWNpcGFudCBEQiBhcyBGaWxlIFN0b3JhZ2UKCiAgICBBcHAtPj5TZXJ2ZXI6IFBPU1QgL2NoZWNrLWltYWdlIChmaWxlKQogICAgU2VydmVyLT4+Q1Y6IENhbGN1bGF0ZSBMYXBsYWNpYW4gVmFyaWFuY2UKICAgIENWLS0+PlNlcnZlcjogQmx1ciBTY29yZSAoZS5nLiwgMTIwLjUpCiAgICAKICAgIGFsdCBTY29yZSA8IFRocmVzaG9sZCAoMTAwLjApCiAgICAgICAgU2VydmVyLS0+PkFwcDogNDAwIEVycm9yIC8gIlRvbyBCbHVycnkiCiAgICBlbHNlIFNjb3JlID49IFRocmVzaG9sZAogICAgICAgIFNlcnZlci0+PkFJOiBQcmVkaWN0KGltYWdlKQogICAgICAgIEFJLS0+PlNlcnZlcjogUHJlZGljdGlvbnMgW01lbGFub21hOiA4MCUsIE5ldmk6IDE1JS4uLl0KICAgICAgICBTZXJ2ZXItPj5EQjogU2F2ZSBJbWFnZSAmIExvZyBNZXRhZGF0YQogICAgICAgIFNlcnZlci0tPj5BcHA6IDIwMCBPSyArIFByZWRpY3Rpb25zCiAgICBlbmQ=)

### 2. Case Logging Workflow
How final diagnoses are saved after the AI result is reviewed.

![Case Logging Diagram](https://mermaid.ink/img/Z3JhcGggTFIKICAgIFVzZXJbRG9jdG9yIENvbmZpcm1zIERpYWdub3Npc10gLS0+fFN1Ym1pdHwgQXBwCiAgICBBcHAgLS0+fFBPU1QgL2Nhc2VzfCBBUEkKICAgIEFQSSAtLT58VmFsaWRhdGUgRGF0YXwgU2NoZW1hW1B5ZGFudGljIFNjaGVtYV0KICAgIFNjaGVtYSAtLT58VmFsaWR8IExvZ2dlcltKU09OTCBMb2dnZXJdCiAgICBMb2dnZXIgLS0+fEFwcGVuZHwgRmlsZVtzdG9yYWdlL21ldGFkYXRhLmpzb25sXQogICAgQVBJIC0tPnxTdWNjZXNzfCBBcHA=)

---

## 📂 Project Structure Deep Dive

Here is an explanation of every important file in the `backserver/` directory:

```plaintext
backserver/
├── back.py                 # 🏁 ENTRY POINT
│   └── Initializes FastAPI, CORS, and defines all API Routes (@app.post).
│
├── model.py                # 🧠 THE BRAIN
│   ├── Loads the .pt model file securely.
│   ├── Preprocesses images (Resize -> CenterCrop -> Normalize).
│   └── Runs inference to get probability scores.
│
├── config.py               # ⚙️ SETTINGS
│   └── Centralizes all constants (Paths, Thresholds, API Keys) using env vars.
│
├── schemas.py              # 📝 DATA CONTRACTS
│   └── Defines what JSON data looks like (Request/Response models).
│
├── storage/                # 🗄️ DATABASE (Local)
│   ├── images/             # Saved JPEGs from users.
│   └── metadata.jsonl      # A text file acting as a database (one JSON per line).
│
└── requirements.txt        # 📦 DEPENDENCIES
    └── List of all Python libraries required to run the server.
```

---

## 🛠 Setup & Installation

### 1. Environment Setup
You need **Python 3.9+**. We recommend using a virtual environment (`venv`) to keep your system clean.

```bash
# Navigate to the directory
cd backserver

# Create virtual environment
python -m venv .venv

# Activate it
# macOS/Linux:
source .venv/bin/activate
# Windows:
# .venv\Scripts\activate
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Verify Model Assets
The server expects the trained AI model to be in the shared assets folder:
- **Expected Path:** `../assets/models/ham10000_resnet50_tuned_best.pt`
- *If missing, the server will start in "Dummy Mode" (random/mock predictions).*

### 4. Run the Server
```bash
# Development mode (auto-restart on code change)
uvicorn back:app --reload
```
The server is now live at: `http://0.0.0.0:8000`

---

## 📡 API Reference

### `POST /check-image`
Analyzes an image.
- **Input:** `multipart/form-data` (key: `file`)
- **Output:** JSON containing `blur_score`, `predictions` (list of classes and confidence), and `status`.

### `GET /cases`
Fetches history.
- **Params:** `limit` (int), `status` (string)
- **Output:** JSON list of past cases.

### `POST /cases`
Saves a confirmed case.
- **Body:** JSON matching `CaseLog` schema (see `schemas.py`).

---

## ⚙️ Configuration (`config.py`)

You can adjust these settings by editing `config.py` or setting Environment Variables.

| Variable | Default | Meaning |
| :--- | :--- | :--- |
| `BLUR_THRESHOLD` | `100.0` | Lower values allow blurrier images. Higher values are stricter. |
| `CONF_THRESHOLD` | `0.5` | Minimum confidence to consider a prediction "valid" (UI logic). |
| `MODEL_DEVICE` | `auto` | Set to `cpu` or `cuda` to force a specific hardware. |
| `BACKSERVER_HOST` | `0.0.0.0` | Listen on all network interfaces. |
| `ENCRYPT_STORAGE` | `` | Set to `true` to encrypt stored images and metadata. |
| `DATA_ENCRYPTION_KEY` | `` | URL-safe base64 key (16/24/32 bytes) used for storage encryption. |
| `TLS_CERT_FILE` | `` | Path to TLS certificate for HTTPS (uvicorn). |
| `TLS_KEY_FILE` | `` | Path to TLS private key for HTTPS (uvicorn). |

When `ENCRYPT_STORAGE` is enabled, images are saved as encrypted `.bin` files and each metadata line is stored as an encrypted JSON wrapper. Keep `DATA_ENCRYPTION_KEY` available to read existing data. For HTTPS, either run `python back.py` with `TLS_CERT_FILE` and `TLS_KEY_FILE` set, or pass `--ssl-certfile` and `--ssl-keyfile` to `uvicorn`.

---

## 🧠 AI Model Details

We use a **ResNet50** architecture (a standard Deep Learning model for image recognition), fine-tuned on the **HAM10000** dataset.

**Classes it detects:**
1.  **akiec**: Actinic keratoses (Pre-cancerous)
2.  **bcc**: Basal cell carcinoma (Cancer)
3.  **bkl**: Benign keratosis (Benign)
4.  **df**: Dermatofibroma (Benign)
5.  **mel**: Melanoma (Dangerous Cancer)
6.  **nv**: Melanocytic nevi (Moles - Benign)
7.  **vasc**: Vascular lesions (Benign)

---

## 🛠 Troubleshooting

**Problem: "ModuleNotFoundError: No module named 'fastapi'"**
> **Fix:** You forgot to install dependencies. Run `pip install -r requirements.txt`.

**Problem: "The system cannot find the path specified" (Model load error)**
> **Fix:** Check if the model file exists at `assets/models/ham10000_resnet50_tuned_best.pt`. If you are running the script from a different directory, the relative path might be wrong.

**Problem: App cannot connect to Localhost**
> **Fix:** Android Emulators cannot see `localhost`. Use `10.0.2.2` instead of `127.0.0.1`.
> - **Wrong:** `http://127.0.0.1:8000/check-image`
> - **Right:** `http://10.0.2.2:8000/check-image`
